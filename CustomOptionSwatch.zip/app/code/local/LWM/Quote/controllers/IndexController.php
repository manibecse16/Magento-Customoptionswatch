<?php

class LWM_Quote_IndexController extends Mage_Core_Controller_Front_Action{
	
	public function sendAction(){
		$response=array();
        $post = $this->getRequest()->getPost();
        $emailTemplate = Mage::getModel('core/email_template')
						->loadDefault('lwm_quote_email_get_quote_template');
		//load the custom template to the email 
		$sender_email=$this->getRequest()->getParam('email');
		$emailTemplateVariables = array();
        $emailTemplateVariables['name'] = $this->getRequest()->getParam('name');
        $emailTemplateVariables['email'] =$sender_email;
		$emailTemplateVariables['phone'] =$this->getRequest()->getParam('phone');
        $emailTemplateVariables['message'] = $this->getRequest()->getParam('message');
		$emailTemplate->setSenderName($this->getRequest()->getParam('name'));
		$emailTemplate->setSenderEmail($sender_email);
		//$ccemail=Mage::getStoreConfig('trans_email/ident_general/email');
		//$ccname=Mage::getStoreConfig('trans_email/ident_general/name');
		//$emailTemplate->getMail()->addCc($ccemail,$ccname);  
		$emailTemplate->setType('html');
		$emailTemplate->setTemplateSubject('Request Quote'.$storeName);
        try {
			$emailTemplate->send(Mage::getStoreConfig('general/store_information/site_email'), "Store Manager", $emailTemplateVariables);
			$response['status']="Success";
			$response['message']="Your request has been sent";
			$this->getResponse()->setBody(Mage::helper('core')->jsonEncode($response));
			return;
		}
		 catch (Exception $e) {
			 Mage::logException($e);
			 $response['status']="Error";
			 $response['message']="Unable to send email.";
			 $this->getResponse()->setBody(Mage::helper('core')->jsonEncode($response));
			return;
        }
	}
}