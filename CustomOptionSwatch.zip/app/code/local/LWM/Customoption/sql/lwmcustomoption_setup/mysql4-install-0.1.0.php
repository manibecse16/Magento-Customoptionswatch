<?php
/**
 * LWM
 * @category    LWM
 * @package     LWM_CustomizeProduct
 */
 /**
 * Creating the new table for options
 * 
 * @category    LWM
 * @package     LWM_CustomizeProduct
 * @author      LWM Developer
 */
$installer = $this;
$installer->startSetup();
$sql=<<<SQLTEXT

CREATE TABLE `catalog_product_option_type_image` (
  `option_type_image_id` int(10) UNSIGNED NOT NULL COMMENT 'Option Type Image ID',
  `option_type_id` int(10) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'Option Type ID',
  `store_id` smallint(5) UNSIGNED NOT NULL DEFAULT '0' COMMENT 'Store ID',
  `image` varchar(255) DEFAULT NULL COMMENT 'Image'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Catalog Product Option Type Image Table';

ALTER TABLE `catalog_product_option_type_image`
  ADD PRIMARY KEY (`option_type_image_id`),
  ADD UNIQUE KEY `UNQ_CATALOG_PRODUCT_OPTION_TYPE_TITLE_OPTION_TYPE_ID_STORE_ID` (`option_type_id`,`store_id`),
  ADD KEY `IDX_CATALOG_PRODUCT_OPTION_TYPE_TITLE_OPTION_TYPE_ID` (`option_type_id`),
  ADD KEY `IDX_CATALOG_PRODUCT_OPTION_TYPE_TITLE_STORE_ID` (`store_id`);
  
ALTER TABLE `catalog_product_option_type_image`
  MODIFY `option_type_image_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'Option Type Image ID';

ALTER TABLE `catalog_product_option_type_image`
  ADD CONSTRAINT `FK_CAT_PRD_OPT_TYPE_OPTION_TYPE_VALUE` FOREIGN KEY (`option_type_id`) REFERENCES `catalog_product_option_type_value` (`option_type_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_CAT_PRD_OPT_TYPE_IMAGE_STORE_ID_CORE_STORE_STORE_ID` FOREIGN KEY (`store_id`) REFERENCES `core_store` (`store_id`) ON DELETE CASCADE ON UPDATE CASCADE;  

SQLTEXT;

$installer->run($sql);
$installer->endSetup();