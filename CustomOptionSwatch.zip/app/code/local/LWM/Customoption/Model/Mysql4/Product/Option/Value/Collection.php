<?php
/**
 
 */
class LWM_Customoption_Model_Mysql4_Product_Option_Value_Collection
    extends Mage_Catalog_Model_Resource_Product_Option_Value_Collection
{
    /**
     * Resource initialization
     */
    protected function _construct()
    {
        $this->_init('catalog/product_option_value');
    }

    /**
     * Add price, title to result
     *
     * @param int $storeId
     * @return Mage_Catalog_Model_Resource_Product_Option_Value_Collection
     */
    public function getValues($storeId)
    {
        $this->addPriceToResult($storeId)
             ->addTitleToResult($storeId);

        return $this;
    }
	/**
     * Add image result
     *
     * @param int $storeId
     * @return LWM_CustomizeProduct_Model_Mysql4_Productattribute_Option_Value_Collection
     */
    public function addImageToResult($storeId)
    {
		$optionImageTable = $this->getTable('lmwcustomoption/product_option_type_image');
        $smallImageExpr = $this->getConnection()
            ->getCheckSql('store_value_image.image IS NULL', 'default_value_image.image', 'store_value_image.image');
			
        $joinExpr = 'store_value_image.option_type_id = main_table.option_type_id AND '
                  . $this->getConnection()->quoteInto('store_value_image.store_id = ?', $storeId);
        $this->getSelect()
            ->join(
                array('default_value_image' => $optionImageTable),
                'default_value_image.option_type_id = main_table.option_type_id',
                array('default_image' => 'image')
            )
            ->joinLeft(
                array('store_value_image' => $optionImageTable),
                $joinExpr,
                array(
                    'store_image'   => 'image',
                    'image'         => $smallImageExpr,
                )
            )
            ->where('default_value_image.store_id = ?', Mage_Catalog_Model_Abstract::DEFAULT_STORE_ID);
			
        return $this;
    }

}
