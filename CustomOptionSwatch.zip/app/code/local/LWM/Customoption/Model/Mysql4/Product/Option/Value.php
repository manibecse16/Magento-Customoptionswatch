<?php
/**
 * Magento
 */
class LWM_Customoption_Model_Mysql4_Product_Option_Value extends Mage_Catalog_Model_Resource_Product_Option_Value
{
    

    /**
     * Proceeed operations after object is saved
     * Save options store data
     *
     * @param Mage_Core_Model_Abstract $object
     * @return Mage_Core_Model_Resource_Db_Abstract
     */
    protected function _afterSave(Mage_Core_Model_Abstract $object)
    {
		$post_data=$object->getOption()->getData();
		if($post_data['type']=='image'||$post_data['type']=='imagepopup'){
		   $this->_saveValueImages($object);
        }   

        return parent::_afterSave($object);
    }


    /**
     * Save option value title data
     *
     * @param Mage_Core_Model_Abstract $object
     */
    protected function _saveValueImages(Mage_Core_Model_Abstract $object)
    {
        $imageTable = $this->getTable('lmwcustomoption/product_option_type_image');
		$optionId=$object->getData('option_id');
		$index_id=$object->getData('index_id');
        $optionValueId=$object->getData('selection_id');
		$bind=array();
	  
		$select = $this->_getReadAdapter()->select()
						->from($imageTable, 'option_type_id')
						->where('option_type_id = ?', (int)$object->getId());
		$optionTypeId = $this->_getReadAdapter()->fetchOne($select);	   
    /* Mage::log($_FILES,null,"imageoption.log",true); 
 */
		/*Uploading function for option images*/
		$small_image=array();
		$smallkey='file_'.$index_id.'_'.$optionValueId.'_option_image';
		if (isset($_FILES[$smallkey]['name']) && $_FILES[$smallkey]['name'] != '') {
			$option_image_small=$this->uploadImage($smallkey,'images',$optionId,$object->getId());
			$bind=array('image' =>$option_image_small);
		}
		
	  
	  /*  Mage::log($bind,null,"imageoption.log",true);  */
	  
      /*Insert or update the customize product image*/
        if ($optionTypeId&&sizeof($bind)>0) {
                $where = array(
                    'option_type_id = ?'    => (int)$optionTypeId
                );
                $this->_getWriteAdapter()->update($imageTable,$bind, $where);
            }elseif($optionTypeId==''){
                $bind1  = array(
                    'option_type_id'    => (int)$object->getId()
                );
				$bind  = array_merge($bind,$bind1);
                $this->_getWriteAdapter()->insert($imageTable, $bind);
            } 
    }
    /**
     * Delete values by option id
     *
     * @param int $optionId
     * @return LWM_Customoption_Model_Mysql4_Product_Option_Value
     */
	public function uploadImage($key,$group_id,$optionId, $valueId)
    {
		
            if (isset($_FILES[$key]['name']) && $_FILES[$key]['name'] != '') {
                try {
                    $isUpdate = Mage::helper('lmwcustomoption')->deleteOptionFile($group_id, $optionId, $valueId, ($valueId?$_FILES[$key]['name']:''));

                    $uploader = new Varien_File_Uploader($key);
                    $uploader->setAllowedExtensions(array('jpg', 'jpeg', 'gif', 'png'));
                    $uploader->setAllowRenameFiles(false);
                    $uploader->setFilesDispersion(false);

                    $saveResult = $uploader->save(Mage::helper('lmwcustomoption')->getOptionsPath($group_id, $optionId, $valueId, $_FILES[$key]['name']));
                    
                    if ($saveResult && isset($saveResult['file'])) {
                        if ($valueId) {
							return  ($group_id ? $group_id : 'options'). DS . $optionId . DS . $valueId . DS . $saveResult['file'];
                        }
                        $result = true;
                    }
                } catch (Exception $e) {
                    if ($e->getMessage()) {
                        Mage::getSingleton('adminhtml/session')->addError($e->getMessage());
                    }
                }
            }
	}	
   
    /**
     * Delete values by option type
     *
     * @param int $optionTypeId
     */
    public function deleteValues($optionTypeId)
    {
		parent::deleteValues($optionTypeId);
		$this->deleteSwatchOption($optionTypeId);
        
    }
	protected function deleteSwatchOption($optionTypeId){
		$readAdapter  = $this->_getReadAdapter();
		$imageTable = $this->getTable('lmwcustomoption/product_option_type_image');
		$columns = array(
			new Zend_Db_Expr($optionTypeId),
			'store_id', 'image'
		);

		$select = $this->_getReadAdapter()->select()
			->from($imageTable, array())
			->where('option_type_id = ?', $optionTypeId)
			->columns($columns);
		$data=$readAdapter->fetchRow($select);
		if($data){
			$condition = array(
				'option_type_id = ?' => $optionTypeId
			);
			$this->_getWriteAdapter()->delete(
				$this->getTable('lmwcustomoption/product_option_type_image'),
				$condition
			);
			$name=explode(DS,$data['image']);
			if(sizeof($name)==4){
			   Mage::log($name,null,"testinig.log",true);
			   Mage::helper('lmwcustomoption')->deleteOptionFile($name[0],$name[1],$name[2],$name[3]);
			}
		}
	}

    /**
     * Duplicate product options value
     *
     * @param Mage_Catalog_Model_Product_Option_Value $object
     * @param int $oldOptionId
     * @param int $newOptionId
     * @return Mage_Catalog_Model_Product_Option_Value
     */
    public function duplicate(Mage_Catalog_Model_Product_Option_Value $object, $oldOptionId, $newOptionId)
    {
        $writeAdapter = $this->_getWriteAdapter();
        $readAdapter  = $this->_getReadAdapter();
        $select       = $readAdapter->select()
            ->from($this->getMainTable())
            ->where('option_id = ?', $oldOptionId);
        $valueData = $readAdapter->fetchAll($select);

        $valueCond = array();

        foreach ($valueData as $data) {
            $optionTypeId = $data[$this->getIdFieldName()];
            unset($data[$this->getIdFieldName()]);
            $data['option_id'] = $newOptionId;

            $writeAdapter->insert($this->getMainTable(), $data);
            $valueCond[$optionTypeId] = $writeAdapter->lastInsertId($this->getMainTable());
        }

        unset($valueData);

        foreach ($valueCond as $oldTypeId => $newTypeId) {
            // price
            $priceTable = $this->getTable('catalog/product_option_type_price');
            $columns = array(
                new Zend_Db_Expr($newTypeId),
                'store_id', 'price', 'price_type'
            );

            $select = $readAdapter->select()
                ->from($priceTable, array())
                ->where('option_type_id = ?', $oldTypeId)
                ->columns($columns);
            $insertSelect = $writeAdapter->insertFromSelect($select, $priceTable,
                array('option_type_id', 'store_id', 'price', 'price_type'));
            $writeAdapter->query($insertSelect);

            // title
            $titleTable = $this->getTable('catalog/product_option_type_title');
            $columns = array(
                new Zend_Db_Expr($newTypeId),
                'store_id', 'title'
            );

            $select = $this->_getReadAdapter()->select()
                ->from($titleTable, array())
                ->where('option_type_id = ?', $oldTypeId)
                ->columns($columns);
            $insertSelect = $writeAdapter->insertFromSelect($select, $titleTable,
                array('option_type_id', 'store_id', 'title'));
            $writeAdapter->query($insertSelect);
			// Swatch Images
			$this->duplicateSwatchOption($newOptionId,$newTypeId, $oldTypeId);
        }

        return $object;
    }
	public function duplicateSwatchOption($optionId,$newTypeId, $oldTypeId){
		$newfile='';
		$writeAdapter = $this->_getWriteAdapter();
        $readAdapter  = $this->_getReadAdapter();
		
		$imageTable = $this->getTable('lmwcustomoption/product_option_type_image');
		$columns = array(
			new Zend_Db_Expr($newTypeId),
			'store_id', 'image'
		);

		$select = $this->_getReadAdapter()->select()
			->from($imageTable, array())
			->where('option_type_id = ?', $oldTypeId)
			->columns($columns);
		$data=$readAdapter->fetchRow($select);
		if($data){
			$oldfile=Mage::getBaseDir('media')  . DS . 'customoption'.DS.$data['image'];
			$newfile=Mage::helper('lmwcustomoption')->copyImage($oldfile,'images',$optionId,$newTypeId);
			if($newfile){
				$newfile="images".DS.$optionId.DS.$newTypeId.DS.$newfile;
				$bind  = array(
                    'option_type_id' => (int)$newTypeId,'store_id'=>$data['store_id'],'image'=>$newfile
                );		
				$writeAdapter->insert($imageTable, $bind);
			}
		}
	}
}
