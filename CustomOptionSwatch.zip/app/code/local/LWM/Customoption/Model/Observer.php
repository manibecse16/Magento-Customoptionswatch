<?php 
class LWM_Customoption_Model_Observer
{
	/*Change the product layout based on the category selection in admin backend*/
	public function changeProductlayout(Varien_Event_Observer $observer){
		$currentProd = Mage::registry('current_product');
		$status=Mage::helper('lmwcustomoption')->isProductlayoutEnable();
		if($currentProd&&$status){
			$catIds = $currentProd->getCategoryIds();
			$enable_category=explode(",",Mage::helper('lmwcustomoption')->getCategories());
			$result = array_intersect($catIds,$enable_category);
			$controller = $observer->getAction();
			$controller->getLayout()->getBlock('root')->setTemplate('page/1column-product-page.phtml');
			if(sizeof($result)>0){
				$controller->getLayout()->getBlock('product.info.media')->setTemplate('catalog/product/view/mediafull.phtml');
			}
		}
	}
	
}