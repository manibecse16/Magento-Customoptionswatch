<?php
class LWM_Customoption_Block_Adminhtml_Catalog_Product_Edit_Tab_Options_Type_Selection extends              Mage_Adminhtml_Block_Catalog_Product_Edit_Tab_Options_Type_Abstract
{
    /**
     * Class constructor
     */
    public function __construct()
    {
        parent::__construct();
        $this->setTemplate('lwm/customoption/options/type/selection.phtml');
        $this->setCanEditPrice(true);
        $this->setCanReadPrice(true);
    }

    protected function _prepareLayout()
    {
        $this->setChild('add_selection_row_button',
            $this->getLayout()->createBlock('adminhtml/widget_button')
                ->setData(array(
                    'label' => Mage::helper('catalog')->__('Add New Row'),
                    'class' => 'add add-selection-row',
                    'id'    => 'add_selection_row_button_{{option_id}}'
                ))
        );

        $this->setChild('delete_selection_row_button',
            $this->getLayout()->createBlock('adminhtml/widget_button')
                ->setData(array(
                    'label' => Mage::helper('catalog')->__('Delete Row'),
                    'class' => 'delete delete-selection-row icon-btn',
                    'id'    => 'delete_selection_row_button'
                ))
        );

        return parent::_prepareLayout();
    }

    public function getAddButtonHtml()
    {
        return $this->getChildHtml('add_selection_row_button');
    }

    public function getDeleteButtonHtml()
    {
        return $this->getChildHtml('delete_selection_row_button');
    }

    public function getPriceTypeSelectHtml()
    {
        $this->getChild('option_price_type')
            ->setData('id', 'product_option_{{id}}_selection_{{selection_id}}_price_type')
            ->setName('product[options][{{id}}][values][{{selection_id}}][price_type]');

        return parent::getPriceTypeSelectHtml();
    }
}
