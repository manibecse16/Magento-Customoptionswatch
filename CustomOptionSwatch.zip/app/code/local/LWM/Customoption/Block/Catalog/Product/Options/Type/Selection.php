<?php
/**
 * Magento
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Open Software License (OSL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://opensource.org/licenses/osl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@magento.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade Magento to newer
 * versions in the future. If you wish to customize Magento for your
 * needs please refer to http://www.magento.com for more information.
 *
 * @category    Mage
 * @package     Mage_Catalog
 * @copyright  Copyright (c) 2006-2016 X.commerce, Inc. and affiliates (http://www.magento.com)
 * @license    http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */


/**
 * Product options text type block
 *
 * @category   Mage
 * @package    Mage_Catalog
 * @author     Magento Core Team <core@magentocommerce.com>
 */
class LWM_Customoption_Block_Catalog_Product_Options_Type_Selection
    extends Mage_Catalog_Block_Product_View_Options_Abstract
{
    /**
     * Return html for control element
     *
     * @return string
     */
    public function getValuesHtml()
    {
        $_option = $this->getOption();
		$valuehtml='';
        $configValue = $this->getProduct()->getPreconfiguredValues()->getData('options/' . $_option->getId());
        $store = $this->getProduct()->getStore();
		$imagepath= Mage::getBaseUrl(Mage_Core_Model_Store::URL_TYPE_MEDIA).'customoption/';
     		
		if ($_option->getType() == LWM_Customoption_Model_Catalog_Product_Option::OPTION_TYPE_IMAGE||$_option->getType() == LWM_Customoption_Model_Catalog_Product_Option::OPTION_TYPE_IMAGE_POPUP) {
            $selectHtml = '<ul id="options-'.$_option->getId().'-list" class="options-list selection">';
            $require = ($_option->getIsRequire()) ? ' validate-one-required-by-name' : '';
            $arraySign = '';
            $type = 'radio';
                    $class = 'radio';
                    if (!$_option->getIsRequire()) {
                        $selectHtml .= '<li><span class="label"><label for="options_'
                            . $_option->getId() . '">' . $this->__('None') . '</label></span><input type="radio" id="options_' . $_option->getId() . '" class="'
                            . $class . ' product-custom-option" name="options[' . $_option->getId() . ']"'
                            . ($this->getSkipJsReloadPrice() ? '' : ' onclick="opConfig.reloadPrice()"')
                            . ' value="" checked="checked" /></li>';
                    }
            $count = 1;
            foreach ($_option->getValues() as $_value) {
                $count++;

                $priceStr = $this->_formatPrice(array(
                    'is_percent'    => ($_value->getPriceType() == 'percent'),
                    'pricing_value' => $_value->getPrice($_value->getPriceType() == 'percent')
                ));

                $htmlValue = $_value->getOptionTypeId();
                if ($arraySign) {
                    $checked = (is_array($configValue) && in_array($htmlValue, $configValue)) ? 'checked' : '';
                } else {
                    $checked = $configValue == $htmlValue ? 'checked' : '';
                }
				/* $imageurl='';
				if($_value->getImage()){
					$filepath="images".DS.$_option->getId().DS.$htmlValue;
					$replace="images".DS.$_option->getId().DS.$htmlValue.DS;
					$filename=str_replace($replace,"",$_value->getImage());
					$imageurl=Mage::helper('lmwcustomoption')->resizeImage($filename,110,110,'customoption'.DS.$filepath);
				} */
				
                $simage=($_value->getImage())?$imagepath.$_value->getImage():$imagepath."option.jpg";
				$image='';
				if($_option->getType() == LWM_Customoption_Model_Catalog_Product_Option::OPTION_TYPE_IMAGE_POPUP){
					if($_value->getImage()){
						$filepath="images".DS.$_option->getId().DS.$htmlValue;
						$replace="images".DS.$_option->getId().DS.$htmlValue.DS;
						$filename=str_replace($replace,"",$_value->getImage());
						$imageurl=Mage::helper('lmwcustomoption')->resizeImage($filename,110,110,'customoption'.DS.$filepath);
					}else{
						$imageurl=$imagepath."option.jpg";
					}
					$image='<div class="option-image"><a class="grouped_elements lsb-preview" data-imagelightbox="myGallery'.$_option->getId().'" data-lsb-group="header'.$_option->getId().'" data-caption="'. $this->escapeHtml($_value->getTitle()).'" title="'. $this->escapeHtml($_value->getTitle()).'" rel="group'.$_option->getId().'" href="'.$simage.'"><img src="'.$imageurl.'" alt="'. $this->escapeHtml($_value->getTitle()).'" title="'. $this->escapeHtml($_value->getTitle()).'" /></a></div>';
			    		
				}else{
					$image='<div class="option-image"><img src="'.$simage.'"  /></div>';
				}
                $selectHtml .= '<li>' .$image. '<div class="selection-input"> <span class="label"><label for="options_' . $_option->getId() . '_' . $count . '">'
                    . $this->escapeHtml($_value->getTitle()) . ' ' . $priceStr . '</label></span>'.'<input type="' . $type . '" class="' . $class . ' ' . $require
                    . ' product-custom-option"'
                    . ($this->getSkipJsReloadPrice() ? '' : ' onclick="opConfig.reloadPrice()"')
                    . ' name="options[' . $_option->getId() . ']' . $arraySign . '" id="options_' . $_option->getId()
                    . '_' . $count . '" value="' . $htmlValue . '" ' . $checked . ' price="'
                    . $this->helper('core')->currencyByStore($_value->getPrice(true), $store, false) . '" />'
                    ;
                if ($_option->getIsRequire()) {
                    $selectHtml .= '<script type="text/javascript">' . '$(\'options_' . $_option->getId() . '_'
                    . $count . '\').advaiceContainer = \'options-' . $_option->getId() . '-container\';'
                    . '$(\'options_' . $_option->getId() . '_' . $count
                    . '\').callbackFunction = \'validateOptionsCallback\';' . '</script>';
                }
                $selectHtml .= '</div></li>';
            }
            $selectHtml .= '</ul>';
			if($_option->getType() == LWM_Customoption_Model_Catalog_Product_Option::OPTION_TYPE_IMAGE_POPUP){
			$selectHtml .= '<script type="text/javascript">' 
					. ' var $gallery'.$_option->getId().' = jQuery("#options-'.$_option->getId().'-list a").simpleLightbox({closeText:"X <span>close</span>",showCounter:  false,animationSlide:   false,docClose:     false,close:true,});' . '</script>';
			}
			return $selectHtml;
        }

       
    }

}
