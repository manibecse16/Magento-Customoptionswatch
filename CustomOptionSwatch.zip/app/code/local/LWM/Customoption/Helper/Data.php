<?php
class LWM_Customoption_Helper_Data extends Mage_Core_Helper_Abstract
{
	public function getOptionsPath($groupId, $optionId = false, $valueId = false) {
        return Mage::getBaseDir('media')  . DS . 'customoption'. DS . ($groupId ? $groupId : 'options') . DS . ($optionId ? $optionId . DS : '') . ($valueId ? $valueId . DS : '');
    } 
	public function deleteOptionFile($groupId, $optionId, $valueId = false, $fileName = '') {
        $dir = $this->getOptionsPath($groupId, $optionId, $valueId);
        if ($fileName) {
            if (file_exists($dir . $fileName)) {
                unlink($dir . $fileName);
                $isEmpty = true;
                if (is_dir($dir)) {
                    $objects = scandir($dir);
                    foreach ($objects as $object) {
                        if ($object=='.' || $object == '..') continue;
                        if (filetype($dir . DS . $object) == "dir") {
                            if (file_exists($dir . $object . DS . $fileName)) unlink($dir . $object . DS . $fileName);
                            continue;
                        }
                        $isEmpty = false;
                    }
                }
                // if empty - remove folder
                if ($isEmpty) $this->deleteFolder($dir);
                return true;
            } else {
                return false;
            }
        } else {
            $this->deleteFolder($dir);
        }
    }
	public function copyImage($file,$groupId, $optionId, $valueId){
		$destinationFolder =$this->getOptionsPath($groupId, $optionId, $valueId);
		$this->_createDestinationFolder($destinationFolder);
		$name=explode(DS,$file);
		$newfilename=$name[sizeof($name)-1];
		$newfile=$destinationFolder.$newfilename;	
	    if ( copy($file, $newfile) ) {
			return $newfilename;
		}	 
		return false;
	}
   private function _createDestinationFolder($destinationFolder)
    {
         if( !$destinationFolder ) {
            return $this;
         }

        if (substr($destinationFolder, -1) == DIRECTORY_SEPARATOR) {
           $destinationFolder = substr($destinationFolder, 0, -1);
        }

         if (!(@is_dir($destinationFolder) || @mkdir($destinationFolder, 0777, true))) {
             throw new Exception("Unable to create directory '{$destinationFolder}'.");
         }
         return $this;
 
         $destinationFolder = str_replace('/', DIRECTORY_SEPARATOR, $destinationFolder);
         $path = explode(DIRECTORY_SEPARATOR, $destinationFolder);
         $newPath = null;
         $oldPath = null;
         foreach( $path as $key => $directory ) {
             if (trim($directory)=='') {
                 continue;
             }
             if (strlen($directory)===2 && $directory{1}===':') {
                 $newPath = $directory;
                 continue;
             }
             $newPath.= ( $newPath != DIRECTORY_SEPARATOR ) ? DIRECTORY_SEPARATOR . $directory : $directory;
             if( is_dir($newPath) ) {
                 $oldPath = $newPath;
                 continue;
             } else {
                 if( is_writable($oldPath) ) {
                     mkdir($newPath, 0777);
                 } else {
                     throw new Exception("Unable to create directory '{$newPath}'. Access forbidden.");
                 }
             }
             $oldPath = $newPath;
         }
         return $this;
     }
	public function deleteFolder($dir) {
        if (is_dir($dir)) {
            $objects = scandir($dir);
            foreach ($objects as $object) {
                if ($object != "." && $object != "..") {
                    if (filetype($dir . DS . $object) == "dir") {
                        $this->deleteFolder($dir . DS . $object);
                    } else {
                        unlink($dir . DS . $object);
                    }
                }
            }
            reset($objects);
            rmdir($dir);
        }
    }
	public function resizeImage($imageName, $width=NULL, $height=NULL, $imagePath=NULL)
	{
        
		$imagePath = str_replace("/", DS, $imagePath);

		$imagePathFull = Mage::getBaseDir('media'). DS . $imagePath . DS . $imageName;

		if($width == NULL && $height == NULL) {

			$width = 100;

			$height = 100;

		}

		$resizePath = $width . 'x' . $height;

		$resizePathFull =Mage::getBaseDir('media'). DS . $imagePath . DS . $resizePath . DS . $imageName;

		if (file_exists($imagePathFull) && !file_exists($resizePathFull)) {

			$imageObj = new Varien_Image($imagePathFull);

			$imageObj->constrainOnly(TRUE);

			$imageObj->keepAspectRatio(TRUE);

			$imageObj->resize($width,$height);

			$imageObj->save($resizePathFull);

		}
		$imagePath=str_replace(DS, '/', $imagePath);
		
		return Mage::getBaseUrl('media') . $imagePath . "/" . $resizePath . "/" . $imageName;

    }
	public function isProductlayoutEnable(){
		return Mage::getStoreConfig('catalog/product_view_layout/is_active');
	}
	public function getCategories(){
		return Mage::getStoreConfig('catalog/product_view_layout/categories');
	}
}
	 